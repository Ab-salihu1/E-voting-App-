import { Router } from 'express'

const router = Router()

// POST /api/notifications/broadcast — ADMIN ONLY: send to a target audience
// (all verified voters / all staff / unverified accounts). Should fan out to
// push/email/SMS depending on what each recipient has enabled.
router.post('/broadcast', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: broadcast to target audience.' })
})

export default router
