import { Router } from 'express'

const router = Router()

// GET /api/tally/:electionId — public, no auth required.
// Returns ONLY aggregate per-party totals, never individual ballots.
router.get('/:electionId', (_req, res) => {
  res.json({
    electionId: _req.params.electionId,
    totals: [], // e.g. [{ party: 'APC', votes: 0 }, ...]
    updatedAt: new Date().toISOString(),
  })
})

export default router
