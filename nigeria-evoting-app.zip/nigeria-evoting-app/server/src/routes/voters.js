import { Router } from 'express'

const router = Router()

// GET /api/voters?status=pending — ADMIN ONLY: list voters awaiting verification
router.get('/', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: list voters, filterable by verification status.' })
})

// PATCH /api/voters/:id/verification — ADMIN ONLY: approve or reject.
// Approval must run the duplicate-account check (NIN hash + face-template
// hash) one more time before flipping status, not just trust the queue entry.
router.patch('/:id/verification', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: re-run duplicate check, then approve/reject.' })
})

export default router
