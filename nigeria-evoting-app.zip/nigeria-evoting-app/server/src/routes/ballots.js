import { Router } from 'express'

const router = Router()

// POST /api/ballots — accepts { votingToken, ballots: [{ contestId,
// encryptedChoice }, ...] } — one voter may be voting in several contests at
// once (e.g. President + Governor + State Assembly + LG Chairman +
// Councillor). Must:
//  1. Reject if votingToken is missing, expired, or already spent (idempotency).
//  2. Write all contests in the array as a single atomic transaction — never
//     partially record some contests and not others.
//  3. Store each encrypted ballot in a store separate from the voter registry,
//     keyed only by the token — never by voter identity.
//  4. Mark the token spent in the same transaction as the write, so a retry
//     with the same token can never insert a second set of ballots.
//  5. Increment the live public per-party tally counter for each contest
//     (aggregate only).
//  6. Generate one receipt for the whole submission, deterministically:
//     HMAC-SHA256(serverSecret, token + submittedAt) — never
//     Math.random()/crypto.randomUUID().
router.post('/', (_req, res) => {
  res.status(501).json({
    message: 'Not implemented yet: validate + spend token, store encrypted ballot, bump tally, return deterministic receipt.',
  })
})

export default router
