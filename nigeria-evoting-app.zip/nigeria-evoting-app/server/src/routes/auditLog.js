import { Router } from 'express'

const router = Router()

// GET /api/audit-log — ADMIN ONLY, read-only. Must be append-only and
// hash-chained at the storage layer — this route should never expose an
// update or delete for any entry.
router.get('/', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: return hash-chained audit log entries, paginated.' })
})

export default router
