import { Router } from 'express'

const router = Router()

// GET /api/elections — list configured elections
router.get('/', (_req, res) => {
  res.json({ elections: [] })
})

// POST /api/elections — INEC-admin only: create election with voting window.
// Body includes { name, level: 'federal'|'state'|'local', state?, lga?,
// startsAt, endsAt, timezone, lockDate }. State-level elections scope to one
// state; local-government-level elections scope to one state + one LGA.
router.post('/', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: create election with start/end date-time, timezone, lock date, and level/state/LGA scope.' })
})

// POST /api/elections/:id/parties — INEC-admin only: onboard a party (name, acronym, logo)
router.post('/:id/parties', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: add party + candidate to election roster.' })
})

// POST /api/elections/:id/lock — INEC-admin only: close the roster to edits.
// Must reject any further party/candidate writes for this election once locked.
router.post('/:id/lock', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: mark roster locked, reject further party/candidate writes.' })
})

export default router
