import { Router } from 'express'

const router = Router()

// POST /api/admin/invites — SUPER-ADMIN ONLY: issue a one-time invite code
// to a verified official's official email. This is the only way a new
// admin/commissioner/Chairman account can come into existence.
router.post('/invites', (_req, res) => {
  res.status(501).json({
    message: 'Not implemented yet: super-admin issues one-time invite code, emailed to official address.',
  })
})

// POST /api/admin/activate — consumes a valid invite code, sets password,
// enrolls MFA. Rejected if the invite is missing/expired/already used.
router.post('/activate', (_req, res) => {
  res.status(501).json({
    message: 'Not implemented yet: validate invite code, create admin account, enforce MFA enrollment.',
  })
})

// POST /api/admin/login — staff ID/email + password + mandatory MFA code.
router.post('/login', (_req, res) => {
  res.status(501).json({
    message: 'Not implemented yet: verify credentials + MFA. MFA required for every admin role, no exceptions.',
  })
})

// GET /api/admin — SUPER-ADMIN ONLY: list all admin/commissioner/staff accounts and their status.
router.get('/', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: list admin accounts with role + status.' })
})

// POST /api/admin/:id/revoke — SUPER-ADMIN ONLY: immediately revoke one
// admin's access. This must (a) disable login for that account, (b)
// invalidate every existing session/refresh token for it right away, and
// (c) write an audit-log entry recording who revoked it and when — it must
// NOT simply delete or overwrite the row, since the audit trail needs to
// show the handover happened.
router.post('/:id/revoke', (_req, res) => {
  res.status(501).json({
    message: 'Not implemented yet: disable login, invalidate active sessions, write audit-log entry.',
  })
})

export default router
