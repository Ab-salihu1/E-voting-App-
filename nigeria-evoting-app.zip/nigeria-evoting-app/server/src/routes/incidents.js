import { Router } from 'express'

const router = Router()

// GET /api/incidents — ADMIN ONLY: list incidents (open + resolved)
router.get('/', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: list incidents.' })
})

// POST /api/incidents — public-facing form on /transparency posts here too,
// just without admin auth required and with rate-limiting to prevent abuse
router.post('/', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: create incident, rate-limited for public submissions.' })
})

// PATCH /api/incidents/:id — ADMIN ONLY: update severity/status
router.patch('/:id', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: update incident status/severity.' })
})

export default router
