import { Router } from 'express'

const router = Router()

// POST /api/auth/signup — email + password account creation
router.post('/signup', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: create account, hash password with Argon2/bcrypt.' })
})

// POST /api/auth/verify-nin — kicks off NIN verification against identity provider
router.post('/verify-nin', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: call identity-provider API, store salted hash only.' })
})

// POST /api/auth/verify-voter-card — validates PVC number against the voter
// roll, also triggers duplicate-account check
router.post('/verify-voter-card', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: validate PVC against roll, run duplicate-account check.' })
})

// POST /api/auth/verify-face — accepts captured frame(s), runs liveness
// detection, hashes the resulting face template, checks it against existing
// enrollments to block duplicate accounts
router.post('/verify-face', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: liveness check, hash face template, duplicate check.' })
})

// POST /api/auth/otp/request and /verify
router.post('/otp/request', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: send OTP via SMS/email.' })
})
router.post('/otp/verify', (_req, res) => {
  res.status(501).json({ message: 'Not implemented yet: verify OTP code.' })
})

// POST /api/auth/vote-login — voter card number + NIN gate, paired with a
// mandatory liveness re-check before a voting token is issued
router.post('/vote-login', (_req, res) => {
  res.status(501).json({
    message:
      'Not implemented yet: validate voter card + NIN, then require a fresh liveness check before issuing a one-time voting token.',
  })
})

export default router
