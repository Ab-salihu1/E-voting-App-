import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import dotenv from 'dotenv'
import authRoutes from './routes/auth.js'
import electionsRoutes from './routes/elections.js'
import tallyRoutes from './routes/tally.js'
import adminRoutes from './routes/admin.js'
import ballotsRoutes from './routes/ballots.js'
import votersRoutes from './routes/voters.js'
import incidentsRoutes from './routes/incidents.js'
import notificationsRoutes from './routes/notifications.js'
import auditLogRoutes from './routes/auditLog.js'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 4000

app.use(helmet())
app.use(cors())
app.use(express.json())

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'nigeria-evoting-server' })
})

app.use('/api/auth', authRoutes)
app.use('/api/elections', electionsRoutes)
app.use('/api/tally', tallyRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/ballots', ballotsRoutes)
app.use('/api/voters', votersRoutes)
app.use('/api/incidents', incidentsRoutes)
app.use('/api/notifications', notificationsRoutes)
app.use('/api/audit-log', auditLogRoutes)

app.listen(PORT, () => {
  console.log(`NaijaVote server listening on port ${PORT}`)
})
