import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import PageTitle from './components/PageTitle'
import Landing from './pages/Landing'
import Leadership from './pages/Leadership'
import Dashboard from './pages/Dashboard'
import Transparency from './pages/Transparency'
import VoteLogin from './pages/vote/VoteLogin'
import VoteLiveness from './pages/vote/VoteLiveness'
import EligibilityCheck from './pages/vote/EligibilityCheck'
import Ballot from './pages/vote/Ballot'
import ReviewVote from './pages/vote/ReviewVote'
import VoteReceipt from './pages/vote/VoteReceipt'
import AdminLogin from './pages/admin/AdminLogin'
import AdminSignup from './pages/admin/AdminSignup'
import ManageAdmins from './pages/admin/ManageAdmins'
import AdminDashboard from './pages/admin/AdminDashboard'
import ElectionSetup from './pages/admin/ElectionSetup'
import PartyOnboarding from './pages/admin/PartyOnboarding'
import VoterRoll from './pages/admin/VoterRoll'
import Incidents from './pages/admin/Incidents'
import Notifications from './pages/admin/Notifications'
import AuditLog from './pages/admin/AuditLog'
import SignUp from './pages/onboarding/SignUp'
import VerifyNin from './pages/onboarding/VerifyNin'
import VerifyOtp from './pages/onboarding/VerifyOtp'
import SetupMfa from './pages/onboarding/SetupMfa'
import VerifyVoterCard from './pages/onboarding/VerifyVoterCard'
import FacialCapture from './pages/onboarding/FacialCapture'
import VerificationComplete from './pages/onboarding/VerificationComplete'

export default function App() {
  return (
    <div className="min-h-screen">
      <PageTitle />
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/leadership" element={<Leadership />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/transparency" element={<Transparency />} />
          <Route path="/vote/login" element={<VoteLogin />} />
          <Route path="/vote/liveness" element={<VoteLiveness />} />
          <Route path="/vote/eligibility" element={<EligibilityCheck />} />
          <Route path="/vote/ballot" element={<Ballot />} />
          <Route path="/vote/review" element={<ReviewVote />} />
          <Route path="/vote/receipt" element={<VoteReceipt />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/verify/nin" element={<VerifyNin />} />
          <Route path="/verify/otp" element={<VerifyOtp />} />
          <Route path="/verify/mfa" element={<SetupMfa />} />
          <Route path="/verify/voter-card" element={<VerifyVoterCard />} />
          <Route path="/verify/face" element={<FacialCapture />} />
          <Route path="/verify/complete" element={<VerificationComplete />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/signup" element={<AdminSignup />} />
          <Route path="/admin/manage" element={<ManageAdmins />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/elections" element={<ElectionSetup />} />
          <Route path="/admin/parties" element={<PartyOnboarding />} />
          <Route path="/admin/voters" element={<VoterRoll />} />
          <Route path="/admin/incidents" element={<Incidents />} />
          <Route path="/admin/notifications" element={<Notifications />} />
          <Route path="/admin/audit-log" element={<AuditLog />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
