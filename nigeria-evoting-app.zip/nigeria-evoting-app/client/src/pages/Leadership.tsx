import EmblemLogo from '../components/EmblemLogo'

// Real-world officeholder shown for realism in this concept design.
// In the actual app, this would be admin-managed data, kept current by INEC
// staff — not hardcoded — since these appointments change over time.
const chairman = {
  name: 'Prof. Joash Ojo Amupitan, SAN',
  title: 'Chairman, Independent National Electoral Commission (INEC)',
  note: 'Sworn in October 2025, succeeding Prof. Mahmood Yakubu.',
}

const commissionerSeats = [
  'National Commissioner — North Central',
  'National Commissioner — North East',
  'National Commissioner — North West',
  'National Commissioner — South East',
  'National Commissioner — South South',
  'National Commissioner — South West',
]

export default function Leadership() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <p className="font-serif text-sm font-semibold uppercase tracking-wide text-green-700 dark:text-gold">
        Transparency portal
      </p>
      <h1 className="mt-3 font-serif text-3xl font-semibold text-ink dark:text-paper sm:text-4xl">
        Commission leadership
      </h1>
      <p className="mt-4 max-w-2xl text-ink/70 dark:text-paper/70">
        This concept app names the real, current head of INEC for realism. In a production build,
        this page would pull directly from INEC's own admin-managed staff records so it's never
        out of date.
      </p>

      <div className="mt-10 flex flex-col gap-5 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal sm:flex-row sm:items-center">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-green-700/10 text-green-700 dark:bg-gold/10 dark:text-gold">
          <EmblemLogo className="h-9 w-9" />
        </div>
        <div>
          <p className="font-serif text-xl font-semibold text-ink dark:text-paper">{chairman.name}</p>
          <p className="text-sm text-ink/70 dark:text-paper/70">{chairman.title}</p>
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">{chairman.note}</p>
        </div>
      </div>

      <h2 className="mt-12 font-serif text-xl font-semibold text-ink dark:text-paper">
        National Commissioners
      </h2>
      <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">
        Six zonal seats sit on the Commission alongside the Chairman. Names are intentionally left
        as admin-fillable placeholders here, since commissioner appointments change over each
        electoral cycle.
      </p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {commissionerSeats.map((seat) => (
          <div
            key={seat}
            className="rounded-xl border border-dashed border-ink/20 p-4 text-sm text-ink/60 dark:border-paper/20 dark:text-paper/60"
          >
            {seat}
            <span className="mt-1 block text-xs text-ink/35 dark:text-paper/35">
              — to be filled by admin
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
