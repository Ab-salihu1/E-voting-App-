import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import OnboardingProgress from '../../components/OnboardingProgress'

export default function SetupMfa() {
  const navigate = useNavigate()
  const [enabled, setEnabled] = useState(false)

  function handleContinue() {
    // If enabled: POST /api/auth/mfa/enroll, then confirm with a code before
    // proceeding. Kept as a single confirm step here since this is optional
    // and not required to reach the ballot — only the vote-time liveness
    // check is mandatory.
    navigate('/verify/voter-card')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
          Add extra protection (optional)
        </p>
      </div>

      <OnboardingProgress current={4} />

      <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <label className="flex items-start gap-3">
          <input
            type="checkbox"
            checked={enabled}
            onChange={(e) => setEnabled(e.target.checked)}
            className="mt-1 h-5 w-5 accent-green-700"
          />
          <span>
            <span className="font-medium text-ink dark:text-paper">
              Enable multi-factor authentication
            </span>
            <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">
              Adds an authenticator-app code on top of your password whenever you sign in.
              Recommended, but not required — your vote-time face check is mandatory either way.
            </p>
          </span>
        </label>

        {enabled && (
          <div className="mt-4 flex flex-col items-center rounded-xl bg-ink/5 p-4 dark:bg-paper/5">
            <div className="flex h-32 w-32 items-center justify-center rounded-lg border border-dashed border-ink/25 text-xs text-ink/40 dark:border-paper/25 dark:text-paper/40">
              QR code placeholder
            </div>
            <p className="mt-3 text-center text-xs text-ink/50 dark:text-paper/50">
              Scan with Google Authenticator, Authy, or similar, then enter the 6-digit code on
              your next sign-in to confirm.
            </p>
          </div>
        )}

        <button
          onClick={handleContinue}
          className="mt-6 w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          {enabled ? 'Continue' : 'Skip for now'}
        </button>
      </div>
    </div>
  )
}
