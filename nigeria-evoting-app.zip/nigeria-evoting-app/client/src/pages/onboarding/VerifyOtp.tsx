import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import OnboardingProgress from '../../components/OnboardingProgress'

export default function VerifyOtp() {
  const navigate = useNavigate()
  const [seconds, setSeconds] = useState(60)

  useEffect(() => {
    if (seconds === 0) return
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000)
    return () => clearTimeout(t)
  }, [seconds])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/auth/otp/verify
    navigate('/verify/mfa')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">Enter your OTP</p>
      </div>

      <OnboardingProgress current={3} />

      <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <p className="text-sm text-ink/70 dark:text-paper/70">
          We sent a 6-digit code to your email and phone number on file.
        </p>
        <div className="flex justify-between gap-2">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <input
              key={i}
              type="text"
              inputMode="numeric"
              maxLength={1}
              required
              className="h-12 w-12 rounded-lg border border-ink/15 bg-transparent text-center text-lg text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
          ))}
        </div>

        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Verify code
        </button>

        <p className="text-center text-sm text-ink/60 dark:text-paper/60">
          {seconds > 0 ? (
            <>Resend code in {seconds}s</>
          ) : (
            <button
              type="button"
              onClick={() => setSeconds(60)}
              className="font-medium text-green-700 dark:text-gold"
            >
              Resend code
            </button>
          )}
        </p>
      </form>
    </div>
  )
}
