import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import OnboardingProgress from '../../components/OnboardingProgress'

export default function VerifyVoterCard() {
  const navigate = useNavigate()

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/auth/verify-voter-card — checks against the voter roll,
    // also runs the duplicate-account check (NIN + biometric hash uniqueness).
    navigate('/verify/face')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">Verify your voter card</p>
      </div>

      <OnboardingProgress current={5} />

      <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div>
          <label htmlFor="pvc" className="block text-sm font-medium text-ink dark:text-paper">
            Voter Card (PVC) number
          </label>
          <input
            id="pvc"
            type="text"
            required
            placeholder="e.g. 90F5A2B1C3D4"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 tracking-widest text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
            Found on the front of your Permanent Voter's Card, under your photo.
          </p>
        </div>

        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Verify voter card
        </button>
      </form>
    </div>
  )
}
