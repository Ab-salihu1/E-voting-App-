import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import OnboardingProgress from '../../components/OnboardingProgress'

export default function VerifyNin() {
  const navigate = useNavigate()

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/auth/verify-nin — calls the identity-provider integration.
    // Only a salted hash reference is ever stored; the raw NIN is never
    // persisted long-term.
    navigate('/verify/otp')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">Verify your NIN</p>
      </div>

      <OnboardingProgress current={2} />

      <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div>
          <label htmlFor="nin" className="block text-sm font-medium text-ink dark:text-paper">
            National Identification Number (NIN)
          </label>
          <input
            id="nin"
            type="text"
            inputMode="numeric"
            pattern="[0-9]{11}"
            maxLength={11}
            required
            placeholder="11-digit NIN"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 tracking-widest text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
            Checked once against the national identity database, then hashed. It's never stored as
            plain text, and never used as your account sign-in password — the separate vote-login
            gate later uses it differently, paired with a fresh face check each time.
          </p>
        </div>

        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Verify NIN
        </button>
      </form>
    </div>
  )
}
