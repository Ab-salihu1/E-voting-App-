import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import OnboardingProgress from '../../components/OnboardingProgress'

type Stage = 'requesting' | 'live' | 'denied' | 'captured'

export default function FacialCapture() {
  const navigate = useNavigate()
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stage, setStage] = useState<Stage>('requesting')
  const [photo, setPhoto] = useState<string | null>(null)

  useEffect(() => {
    let stream: MediaStream | null = null
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: 'user' } })
      .then((s) => {
        stream = s
        if (videoRef.current) videoRef.current.srcObject = s
        setStage('live')
      })
      .catch(() => setStage('denied'))
    return () => stream?.getTracks().forEach((t) => t.stop())
  }, [])

  function capture() {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    const ctx = canvas.getContext('2d')
    ctx?.drawImage(video, 0, 0)
    setPhoto(canvas.toDataURL('image/jpeg'))
    setStage('captured')
    // In the real build: this frame (plus a short liveness sequence — e.g. a
    // prompted blink or head turn) goes to the liveness-detection service,
    // and the resulting face template is hashed and checked against existing
    // enrollments for duplicate-account prevention.
  }

  function submit() {
    navigate('/verify/complete')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">Face &amp; liveness check</p>
      </div>

      <OnboardingProgress current={6} />

      <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div className="relative mx-auto aspect-square w-64 overflow-hidden rounded-full bg-ink/5 dark:bg-paper/5">
          {stage !== 'captured' && (
            <video ref={videoRef} autoPlay playsInline muted className="h-full w-full scale-x-[-1] object-cover" />
          )}
          {stage === 'captured' && photo && (
            <img src={photo} alt="Captured selfie" className="h-full w-full scale-x-[-1] object-cover" />
          )}
          <div className="pointer-events-none absolute inset-0 rounded-full ring-2 ring-green-700/40 dark:ring-gold/40" />
        </div>
        <canvas ref={canvasRef} className="hidden" />

        <p className="mt-5 text-center text-sm text-ink/70 dark:text-paper/70">
          {stage === 'requesting' && 'Requesting camera access…'}
          {stage === 'denied' && 'Camera access was denied — enable it in your browser settings to continue.'}
          {stage === 'live' && 'Center your face in the circle, then blink slowly before capturing.'}
          {stage === 'captured' && 'Looks good. Submit to continue, or retake.'}
        </p>

        <div className="mt-5 flex gap-3">
          {stage === 'live' && (
            <button
              onClick={capture}
              className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
            >
              Capture
            </button>
          )}
          {stage === 'captured' && (
            <>
              <button
                onClick={() => setStage('live')}
                className="w-full rounded-full border border-ink/20 py-2.5 font-semibold text-ink dark:border-paper/30 dark:text-paper"
              >
                Retake
              </button>
              <button
                onClick={submit}
                className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
              >
                Submit
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
