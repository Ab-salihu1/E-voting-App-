import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import OnboardingProgress from '../../components/OnboardingProgress'

function passwordStrength(pw: string) {
  let score = 0
  if (pw.length >= 10) score++
  if (/[A-Z]/.test(pw)) score++
  if (/[0-9]/.test(pw)) score++
  if (/[^A-Za-z0-9]/.test(pw)) score++
  return score // 0-4
}

const strengthLabel = ['Too weak', 'Weak', 'Okay', 'Strong', 'Very strong']
const strengthColor = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-green-600', 'bg-green-700']

export default function SignUp() {
  const navigate = useNavigate()
  const [password, setPassword] = useState('')
  const score = passwordStrength(password)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/auth/signup happens here in the real build
    navigate('/verify/nin')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
          Create your voter account
        </p>
      </div>

      <OnboardingProgress current={1} />

      <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-ink dark:text-paper">
            Email address
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            placeholder="you@example.com"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">This becomes your sign-in username.</p>
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-ink dark:text-paper">
            Create a password
          </label>
          <input
            id="password"
            type="password"
            required
            minLength={10}
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
          {password.length > 0 && (
            <div className="mt-2">
              <div className="flex h-1.5 gap-1">
                {[0, 1, 2, 3].map((i) => (
                  <span
                    key={i}
                    className={`h-full flex-1 rounded-full ${i < score ? strengthColor[score] : 'bg-ink/10 dark:bg-paper/10'}`}
                  />
                ))}
              </div>
              <p className="mt-1 text-xs text-ink/50 dark:text-paper/50">{strengthLabel[score]}</p>
            </div>
          )}
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
            10+ characters, mixing upper/lowercase, a number, and a symbol.
          </p>
        </div>

        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Continue
        </button>
      </form>
    </div>
  )
}
