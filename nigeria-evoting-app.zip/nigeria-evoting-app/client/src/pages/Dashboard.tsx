import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import EmblemLogo from '../components/EmblemLogo'

// Demo data — in the real build this comes from GET /api/voters/me and
// GET /api/elections (filtered to the voter's constituency).
const election = {
  name: 'Presidential & National Assembly Election',
  opensAt: new Date('2027-02-13T08:00:00+01:00'),
  closesAt: new Date('2027-02-13T18:00:00+01:00'),
}

const notifications = [
  { id: 1, text: 'Your identity verification was approved.', time: '2h ago' },
  { id: 2, text: 'Polling opens in your constituency on 13 Feb 2027.', time: '1d ago' },
]

function useCountdown(target: Date) {
  const [msLeft, setMsLeft] = useState(target.getTime() - Date.now())
  useEffect(() => {
    const t = setInterval(() => setMsLeft(target.getTime() - Date.now()), 1000)
    return () => clearInterval(t)
  }, [target])
  const clamped = Math.max(msLeft, 0)
  const days = Math.floor(clamped / 86400000)
  const hours = Math.floor((clamped % 86400000) / 3600000)
  const minutes = Math.floor((clamped % 3600000) / 60000)
  const seconds = Math.floor((clamped % 60000) / 1000)
  return { days, hours, minutes, seconds, isOpen: msLeft <= 0 }
}

export default function Dashboard() {
  const countdown = useCountdown(election.opensAt)
  const verified = true // demo state
  const hasVoted = false // demo state

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <div>
          <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">
            Welcome back
          </h1>
          <p className="text-sm text-ink/60 dark:text-paper/60">Your voter dashboard</p>
        </div>
      </div>

      <div className="grid gap-6 sm:grid-cols-2">
        {/* Verification status */}
        <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
          <p className="text-sm font-medium text-ink/60 dark:text-paper/60">Verification status</p>
          <div className="mt-2 flex items-center gap-2">
            <span
              className={
                verified
                  ? 'h-2.5 w-2.5 rounded-full bg-green-600'
                  : 'h-2.5 w-2.5 rounded-full bg-yellow-500'
              }
            />
            <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
              {verified ? 'Verified' : 'Pending review'}
            </p>
          </div>
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
            NIN, voter card, and face match all cleared.
          </p>
        </div>

        {/* Vote status */}
        <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
          <p className="text-sm font-medium text-ink/60 dark:text-paper/60">Your vote</p>
          <div className="mt-2 flex items-center gap-2">
            <span
              className={
                hasVoted
                  ? 'h-2.5 w-2.5 rounded-full bg-green-600'
                  : 'h-2.5 w-2.5 rounded-full bg-ink/20 dark:bg-paper/20'
              }
            />
            <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
              {hasVoted ? 'Vote cast' : 'Not yet cast'}
            </p>
          </div>
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
            {hasVoted ? 'Thank you for voting.' : 'You can vote once polling opens below.'}
          </p>
        </div>

        {/* Election + countdown */}
        <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal sm:col-span-2">
          <p className="text-sm font-medium text-ink/60 dark:text-paper/60">{election.name}</p>
          {!countdown.isOpen ? (
            <>
              <div className="mt-3 grid grid-cols-4 gap-3 text-center">
                {[
                  ['Days', countdown.days],
                  ['Hours', countdown.hours],
                  ['Min', countdown.minutes],
                  ['Sec', countdown.seconds],
                ].map(([label, value]) => (
                  <div key={label as string} className="rounded-xl bg-ink/5 py-3 dark:bg-paper/5">
                    <p className="font-serif text-2xl font-semibold text-ink dark:text-paper">
                      {String(value).padStart(2, '0')}
                    </p>
                    <p className="text-xs text-ink/50 dark:text-paper/50">{label}</p>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-xs text-ink/45 dark:text-paper/45">Until polling opens</p>
            </>
          ) : (
            <div className="mt-4 flex items-center justify-between">
              <p className="font-serif text-lg font-semibold text-green-700 dark:text-gold">
                Polling is open now
              </p>
              {!hasVoted && verified && (
                <Link
                  to="/vote/login"
                  className="rounded-full bg-green-700 px-5 py-2.5 font-semibold text-white hover:bg-green-900"
                >
                  Vote now
                </Link>
              )}
            </div>
          )}
        </div>

        {/* Notifications */}
        <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal sm:col-span-2">
          <p className="text-sm font-medium text-ink/60 dark:text-paper/60">Notifications</p>
          <ul className="mt-3 divide-y divide-ink/10 dark:divide-paper/10">
            {notifications.map((n) => (
              <li key={n.id} className="flex items-center justify-between py-3 text-sm">
                <span className="text-ink dark:text-paper">{n.text}</span>
                <span className="text-xs text-ink/40 dark:text-paper/40">{n.time}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap gap-4 text-sm">
        <Link to="/leadership" className="font-medium text-green-700 dark:text-gold">
          Commission leadership →
        </Link>
        <a href="#" className="font-medium text-green-700 dark:text-gold">
          Help centre →
        </a>
      </div>
    </div>
  )
}
