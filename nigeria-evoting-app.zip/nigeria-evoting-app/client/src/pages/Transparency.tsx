import { useEffect, useState } from 'react'
import EmblemLogo from '../components/EmblemLogo'
import PartyBadge from '../components/PartyBadge'
import Skeleton from '../components/Skeleton'

const tallies = [
  {
    contest: 'President',
    rows: [
      { party: 'APC', pct: 0 },
      { party: 'PDP', pct: 0 },
      { party: 'LP', pct: 0 },
      { party: 'NNPP', pct: 0 },
    ],
  },
  {
    contest: 'Governor — Kogi State',
    rows: [
      { party: 'APC', pct: 0 },
      { party: 'PDP', pct: 0 },
      { party: 'LP', pct: 0 },
    ],
  },
]

export default function Transparency() {
  const [reported, setReported] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // GET /api/tally + GET /api/elections/:id/turnout in the real build
    const t = setTimeout(() => setLoading(false), 500)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <p className="font-serif text-sm font-semibold uppercase tracking-wide text-green-700 dark:text-gold">
        Observer &amp; transparency portal
      </p>
      <div className="mt-3 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper sm:text-3xl">
          Open to anyone — no login required
        </h1>
      </div>

      {/* Turnout stats */}
      {loading ? (
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </div>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {[
            ['Registered voters', '—'],
            ['Votes cast so far', '0'],
            ['Turnout', '0%'],
          ].map(([label, value]) => (
            <div key={label} className="rounded-xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal">
              <p className="font-serif text-2xl font-semibold text-ink dark:text-paper">{value}</p>
              <p className="text-xs text-ink/50 dark:text-paper/50">{label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Live tallies per contest */}
      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Live tally by contest
      </h2>
      {loading ? (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : (
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {tallies.map((t) => (
            <div key={t.contest} className="rounded-2xl border border-ink/10 bg-white p-5 dark:border-paper/10 dark:bg-charcoal">
              <p className="text-sm font-semibold text-ink dark:text-paper">{t.contest}</p>
              <ul className="mt-3 space-y-2">
                {t.rows.map((row) => (
                  <li key={row.party}>
                    <div className="mb-1 flex items-center justify-between text-xs font-medium text-ink/70 dark:text-paper/70">
                      <span className="flex items-center gap-1.5">
                        <PartyBadge party={row.party} size="sm" />
                        {row.party}
                      </span>
                      <span>{row.pct}%</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink/5 dark:bg-paper/10">
                      <div className="h-full rounded-full bg-green-700 dark:bg-gold" style={{ width: `${row.pct}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
      <p className="mt-3 text-xs text-ink/40 dark:text-paper/40">
        Aggregate totals only — individual votes are never shown here or anywhere else.
      </p>

      {/* Audit summary */}
      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Audit trail summary
      </h2>
      <div className="mt-4 rounded-2xl border border-ink/10 bg-white p-5 text-sm text-ink/70 dark:border-paper/10 dark:bg-charcoal dark:text-paper/70">
        Every system action is written to a hash-chained, append-only log. Observers can verify
        the chain independently without ever seeing an individual ballot — the full log is
        available to accredited observers on request; a public checkpoint hash will be posted here
        once voting opens.
      </div>

      {/* Public incident reporting */}
      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Report an incident
      </h2>
      {reported ? (
        <div className="mt-4 rounded-2xl border border-green-700/30 bg-green-700/5 p-5 text-sm text-ink dark:border-gold/30 dark:bg-gold/10 dark:text-paper">
          Thanks — your report has been logged for review by election administrators.
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault()
            setReported(true)
          }}
          className="mt-4 space-y-3 rounded-2xl border border-ink/10 bg-white p-5 dark:border-paper/10 dark:bg-charcoal"
        >
          <textarea
            required
            rows={3}
            placeholder="Describe what you observed, including location if relevant…"
            className="w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
          <button
            type="submit"
            className="rounded-full bg-green-700 px-6 py-2.5 font-semibold text-white hover:bg-green-900"
          >
            Submit report
          </button>
        </form>
      )}
    </div>
  )
}
