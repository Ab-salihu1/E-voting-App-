import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import PartyBadge from '../../components/PartyBadge'

const contestLabels: Record<string, { title: string; level: string }> = {
  president: { title: 'President', level: 'Federal' },
  governor: { title: 'Governor — Kogi State', level: 'State' },
  'state-assembly': { title: 'State House of Assembly — Ankpa Constituency', level: 'State' },
  'lg-chairman': { title: 'Local Government Chairman — Ankpa LGA', level: 'Local Government' },
  councillor: { title: 'Councillor — Ankpa Ward 3', level: 'Local Government' },
}

const candidateLookup: Record<string, { party: string; name: string }> = {
  'pres-apc': { party: 'APC', name: 'Candidate A' },
  'pres-pdp': { party: 'PDP', name: 'Candidate B' },
  'pres-lp': { party: 'LP', name: 'Candidate C' },
  'pres-nnpp': { party: 'NNPP', name: 'Candidate D' },
  'gov-apc': { party: 'APC', name: 'Candidate E' },
  'gov-pdp': { party: 'PDP', name: 'Candidate F' },
  'gov-lp': { party: 'LP', name: 'Candidate G' },
  'sha-apc': { party: 'APC', name: 'Candidate H' },
  'sha-pdp': { party: 'PDP', name: 'Candidate I' },
  'lgc-apc': { party: 'APC', name: 'Candidate J' },
  'lgc-pdp': { party: 'PDP', name: 'Candidate K' },
  'clr-apc': { party: 'APC', name: 'Candidate L' },
  'clr-pdp': { party: 'PDP', name: 'Candidate M' },
}

export default function ReviewVote() {
  const navigate = useNavigate()
  const [submitting, setSubmitting] = useState(false)
  const raw = sessionStorage.getItem('naijavote_selections')
  const selections: Record<string, string> = raw ? JSON.parse(raw) : {}
  const contestIds = Object.keys(selections)

  function handleConfirm() {
    if (contestIds.length === 0) return
    setSubmitting(true)
    // POST /api/ballots — one encrypted ballot per contest, all tied to the
    // same one-time voting token, submitted as a single atomic transaction
    // so a voter can't end up with some contests recorded and others not.
    setTimeout(() => navigate('/vote/receipt'), 600)
  }

  if (contestIds.length === 0) {
    return (
      <div className="mx-auto max-w-md px-6 py-16 text-center text-ink/60 dark:text-paper/60">
        No selections found — please{' '}
        <button onClick={() => navigate('/vote/ballot')} className="text-green-700 underline dark:text-gold">
          go back to the ballot
        </button>
        .
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">Review your votes</p>
      </div>

      <div className="space-y-3">
        {contestIds.map((contestId) => {
          const contest = contestLabels[contestId]
          const candidate = candidateLookup[selections[contestId]]
          if (!contest || !candidate) return null
          return (
            <div
              key={contestId}
              className="flex items-start gap-3 rounded-2xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal"
            >
              <PartyBadge party={candidate.party} />
              <div>
                <p className="text-xs uppercase tracking-wide text-ink/45 dark:text-paper/45">
                  {contest.level} · {contest.title}
                </p>
                <p className="mt-1 font-serif text-lg font-semibold text-ink dark:text-paper">
                  {candidate.name}
                </p>
                <p className="text-sm text-ink/60 dark:text-paper/60">{candidate.party}</p>
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-5 rounded-xl bg-ink/5 p-4 text-sm text-ink/70 dark:bg-paper/5 dark:text-paper/70">
        Once you submit, none of this can be changed and you cannot vote again. Your identity is
        never stored alongside any of these choices.
      </div>

      <div className="mt-6 flex gap-3">
        <button
          onClick={() => navigate('/vote/ballot')}
          className="w-full rounded-full border border-ink/20 py-2.5 font-semibold text-ink dark:border-paper/30 dark:text-paper"
        >
          Change votes
        </button>
        <button
          onClick={handleConfirm}
          disabled={submitting}
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900 disabled:opacity-60"
        >
          {submitting ? 'Submitting…' : 'Confirm & submit'}
        </button>
      </div>
    </div>
  )
}
