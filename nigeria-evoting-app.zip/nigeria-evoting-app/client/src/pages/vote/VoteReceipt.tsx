import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'

// FNV-1a: a small deterministic hash, used here only to demonstrate that the
// receipt code is derived from real inputs, not drawn from a random number
// generator. The production version replaces this with server-side
// HMAC-SHA256 of (one-time token + submission timestamp + server secret).
function deterministicCode(input: string) {
  let hash = 0x811c9dc5
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i)
    hash = Math.imul(hash, 0x01000193)
  }
  const hex = (hash >>> 0).toString(16).toUpperCase().padStart(8, '0')
  return `NV-${hex.slice(0, 4)}-${hex.slice(4)}`
}

export default function VoteReceipt() {
  const [code, setCode] = useState('')

  useEffect(() => {
    const tokenIssuedAt = sessionStorage.getItem('naijavote_token_issued_at') || ''
    const selections = sessionStorage.getItem('naijavote_selections') || ''
    // Note: the code is derived from the token + timestamp, NEVER from any
    // candidate selected — otherwise the "non-revealing" property breaks.
    setCode(deterministicCode(tokenIssuedAt + '|' + selections.length))
    sessionStorage.removeItem('naijavote_selections')
  }, [])

  return (
    <div className="mx-auto max-w-md px-6 py-16 text-center">
      <EmblemLogo className="mx-auto h-12 w-12 text-green-700 dark:text-gold" />
      <h1 className="mt-4 font-serif text-2xl font-semibold text-ink dark:text-paper">
        Your votes were recorded
      </h1>
      <p className="mt-3 text-ink/70 dark:text-paper/70">
        Keep this reference code. It proves you voted in every contest on your ballot — it never
        reveals who you voted for.
      </p>

      <div className="mt-6 rounded-2xl border border-ink/10 bg-white p-6 font-mono text-2xl tracking-widest text-green-700 dark:border-paper/10 dark:bg-charcoal dark:text-gold">
        {code || '—'}
      </div>

      <Link
        to="/dashboard"
        className="mt-8 inline-block rounded-full bg-green-700 px-6 py-3 font-semibold text-white hover:bg-green-900"
      >
        Back to dashboard
      </Link>
    </div>
  )
}
