import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'

type Stage = 'requesting' | 'live' | 'denied' | 'captured'

export default function VoteLiveness() {
  const navigate = useNavigate()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [stage, setStage] = useState<Stage>('requesting')

  useEffect(() => {
    let stream: MediaStream | null = null
    navigator.mediaDevices
      ?.getUserMedia({ video: { facingMode: 'user' } })
      .then((s) => {
        stream = s
        if (videoRef.current) videoRef.current.srcObject = s
        setStage('live')
      })
      .catch(() => setStage('denied'))
    return () => stream?.getTracks().forEach((t) => t.stop())
  }, [])

  function confirmAndContinue() {
    setStage('captured')
    // In the real build: this frame goes to the liveness service and is
    // matched against the face template stored at sign-up. Only on a match
    // does the server issue a single-use voting token — this screen never
    // issues one client-side.
    sessionStorage.setItem('naijavote_token_issued_at', new Date().toISOString())
    navigate('/vote/eligibility')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">One more check</p>
      </div>

      <div className="rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div className="relative mx-auto aspect-square w-56 overflow-hidden rounded-full bg-ink/5 dark:bg-paper/5">
          <video ref={videoRef} autoPlay playsInline muted className="h-full w-full scale-x-[-1] object-cover" />
          <div className="pointer-events-none absolute inset-0 rounded-full ring-2 ring-green-700/40 dark:ring-gold/40" />
        </div>
        <p className="mt-5 text-center text-sm text-ink/70 dark:text-paper/70">
          {stage === 'requesting' && 'Requesting camera access…'}
          {stage === 'denied' && 'Camera access is required to vote — enable it and reload.'}
          {stage === 'live' && 'Look at the camera and hold still.'}
          {stage === 'captured' && 'Match confirmed. Taking you to your ballot…'}
        </p>
        {stage === 'live' && (
          <button
            onClick={confirmAndContinue}
            className="mt-5 w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
          >
            Confirm face match
          </button>
        )}
      </div>
    </div>
  )
}
