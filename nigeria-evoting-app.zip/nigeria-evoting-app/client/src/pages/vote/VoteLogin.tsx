import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'

export default function VoteLogin() {
  const navigate = useNavigate()

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/auth/vote-login — validates PVC + NIN against the roll.
    // This alone does NOT issue a voting token — see the security note below.
    navigate('/vote/liveness')
  }

  return (
    <div className="mx-auto flex min-h-[75vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <p className="font-serif text-lg font-semibold text-ink dark:text-paper">Confirm it's you</p>
      </div>

      <div className="mb-6 rounded-xl border border-gold/40 bg-gold/10 p-4 text-sm text-ink/80 dark:text-paper/80">
        Your voter card and NIN unlock this step, but they don't cast your vote on their own —
        you'll also need a fresh face check next, every single time.
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div>
          <label htmlFor="pvc" className="block text-sm font-medium text-ink dark:text-paper">
            Voter Card (PVC) number
          </label>
          <input
            id="pvc"
            type="text"
            required
            autoComplete="username"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 tracking-widest text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <div>
          <label htmlFor="nin" className="block text-sm font-medium text-ink dark:text-paper">
            NIN
          </label>
          <input
            id="nin"
            type="password"
            inputMode="numeric"
            maxLength={11}
            required
            autoComplete="current-password"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 tracking-widest text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Continue to face check
        </button>
      </form>
    </div>
  )
}
