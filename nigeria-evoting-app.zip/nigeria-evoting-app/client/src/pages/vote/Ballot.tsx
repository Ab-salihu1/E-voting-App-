import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'
import PartyBadge from '../../components/PartyBadge'

type Candidate = { id: string; party: string; name: string; initials: string }
type Contest = { id: string; title: string; level: 'Federal' | 'State' | 'Local Government'; candidates: Candidate[] }

// Demo roster — in the real build this is fetched from GET /api/elections
// and filtered to whichever federal/state/LGA contests apply to this voter's
// registered address, for whichever elections are currently open.
const contests: Contest[] = [
  {
    id: 'president',
    title: 'President',
    level: 'Federal',
    candidates: [
      { id: 'pres-apc', party: 'APC', name: 'Candidate A', initials: 'CA' },
      { id: 'pres-pdp', party: 'PDP', name: 'Candidate B', initials: 'CB' },
      { id: 'pres-lp', party: 'LP', name: 'Candidate C', initials: 'CC' },
      { id: 'pres-nnpp', party: 'NNPP', name: 'Candidate D', initials: 'CD' },
    ],
  },
  {
    id: 'governor',
    title: 'Governor — Kogi State',
    level: 'State',
    candidates: [
      { id: 'gov-apc', party: 'APC', name: 'Candidate E', initials: 'CE' },
      { id: 'gov-pdp', party: 'PDP', name: 'Candidate F', initials: 'CF' },
      { id: 'gov-lp', party: 'LP', name: 'Candidate G', initials: 'CG' },
    ],
  },
  {
    id: 'state-assembly',
    title: 'State House of Assembly — Ankpa Constituency',
    level: 'State',
    candidates: [
      { id: 'sha-apc', party: 'APC', name: 'Candidate H', initials: 'CH' },
      { id: 'sha-pdp', party: 'PDP', name: 'Candidate I', initials: 'CI' },
    ],
  },
  {
    id: 'lg-chairman',
    title: 'Local Government Chairman — Ankpa LGA',
    level: 'Local Government',
    candidates: [
      { id: 'lgc-apc', party: 'APC', name: 'Candidate J', initials: 'CJ' },
      { id: 'lgc-pdp', party: 'PDP', name: 'Candidate K', initials: 'CK' },
    ],
  },
  {
    id: 'councillor',
    title: 'Councillor — Ankpa Ward 3',
    level: 'Local Government',
    candidates: [
      { id: 'clr-apc', party: 'APC', name: 'Candidate L', initials: 'CL' },
      { id: 'clr-pdp', party: 'PDP', name: 'Candidate M', initials: 'CM' },
    ],
  },
]

export default function Ballot() {
  const navigate = useNavigate()
  const [index, setIndex] = useState(0)
  const [selections, setSelections] = useState<Record<string, string>>({})

  const contest = contests[index]
  const selected = selections[contest.id]
  const isLast = index === contests.length - 1

  function choose(candidateId: string) {
    setSelections((s) => ({ ...s, [contest.id]: candidateId }))
  }

  function next() {
    if (!selected) return
    if (isLast) {
      sessionStorage.setItem('naijavote_selections', JSON.stringify(selections))
      navigate('/vote/review')
    } else {
      setIndex((i) => i + 1)
    }
  }

  return (
    <div className="mx-auto max-w-lg px-6 py-16">
      <div className="mb-2 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <div>
          <p className="font-serif text-lg font-semibold text-ink dark:text-paper">{contest.title}</p>
          <p className="text-xs text-ink/50 dark:text-paper/50">
            {contest.level} contest · {index + 1} of {contests.length}
          </p>
        </div>
      </div>

      <div className="mb-6 mt-3 flex gap-1">
        {contests.map((c, i) => (
          <div
            key={c.id}
            className={
              'h-1.5 flex-1 rounded-full ' +
              (i < index
                ? 'bg-green-700 dark:bg-gold'
                : i === index
                ? 'bg-green-700/50 dark:bg-gold/50'
                : 'bg-ink/10 dark:bg-paper/10')
            }
          />
        ))}
      </div>

      <fieldset className="space-y-3">
        <legend className="sr-only">Choose your candidate for {contest.title}</legend>
        {contest.candidates.map((c) => (
          <label
            key={c.id}
            className={
              'flex cursor-pointer items-center gap-4 rounded-2xl border p-4 transition ' +
              (selected === c.id
                ? 'border-green-700 bg-green-700/5 dark:border-gold dark:bg-gold/10'
                : 'border-ink/10 bg-white hover:border-ink/25 dark:border-paper/10 dark:bg-charcoal')
            }
          >
            <input
              type="radio"
              name={contest.id}
              value={c.id}
              checked={selected === c.id}
              onChange={() => choose(c.id)}
              className="h-5 w-5 accent-green-700"
            />
            <div className="flex h-12 w-12 shrink-0 items-center justify-center">
              <PartyBadge party={c.party} size="lg" />
            </div>
            <div>
              <p className="font-medium text-ink dark:text-paper">{c.name}</p>
              <p className="text-sm text-ink/60 dark:text-paper/60">{c.party}</p>
            </div>
          </label>
        ))}
      </fieldset>

      <div className="mt-6 flex gap-3">
        {index > 0 && (
          <button
            onClick={() => setIndex((i) => i - 1)}
            className="rounded-full border border-ink/20 px-5 py-3 font-semibold text-ink dark:border-paper/30 dark:text-paper"
          >
            Back
          </button>
        )}
        <button
          onClick={next}
          disabled={!selected}
          className="flex-1 rounded-full bg-green-700 py-3 font-semibold text-white hover:bg-green-900 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {isLast ? 'Review all my votes' : 'Next contest'}
        </button>
      </div>
      <p className="mt-3 text-center text-xs text-ink/40 dark:text-paper/40">
        Party logos/photos shown here are placeholders — swap in the roster INEC admins upload
        during party onboarding.
      </p>
    </div>
  )
}
