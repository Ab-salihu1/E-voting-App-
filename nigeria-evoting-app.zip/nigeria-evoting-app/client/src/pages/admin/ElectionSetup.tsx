import { useState } from 'react'
import EmblemLogo from '../../components/EmblemLogo'

type ElectionLevel = 'federal' | 'state' | 'local'

type ElectionDraft = {
  id: string
  name: string
  level: ElectionLevel
  state: string
  lga: string
  startsAt: string
  endsAt: string
  timezone: string
  lockDate: string
  status: 'draft' | 'locked'
}

const timezones = ['Africa/Lagos (WAT, UTC+1)']

const levelOptions: { value: ElectionLevel; label: string; hint: string }[] = [
  { value: 'federal', label: 'Federal', hint: 'President & National Assembly — nationwide' },
  { value: 'state', label: 'State', hint: 'Governor & State House of Assembly — one state' },
  { value: 'local', label: 'Local Government', hint: 'LG Chairman & Councillors — one LGA' },
]

export default function ElectionSetup() {
  const [elections, setElections] = useState<ElectionDraft[]>([])
  const [form, setForm] = useState({
    name: '',
    level: 'federal' as ElectionLevel,
    state: '',
    lga: '',
    startsAt: '',
    endsAt: '',
    timezone: timezones[0],
    lockDate: '',
  })

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/elections
    setElections((list) => [
      ...list,
      { id: crypto.randomUUID(), ...form, status: 'draft' },
    ])
    setForm({
      name: '',
      level: 'federal',
      state: '',
      lga: '',
      startsAt: '',
      endsAt: '',
      timezone: timezones[0],
      lockDate: '',
    })
  }

  function lockRoster(id: string) {
    // POST /api/elections/:id/lock — after this, party/candidate CRUD closes
    // and the roster becomes read-only for the voting window.
    setElections((list) => list.map((e) => (e.id === id ? { ...e, status: 'locked' } : e)))
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">
          Election setup &amp; scheduling
        </h1>
      </div>

      <form
        onSubmit={handleSubmit}
        className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal"
      >
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-ink dark:text-paper">
            Election name
          </label>
          <input
            id="name"
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="e.g. Presidential & National Assembly Election"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-ink dark:text-paper">Election level</label>
          <div className="mt-2 grid gap-2 sm:grid-cols-3">
            {levelOptions.map((opt) => (
              <label
                key={opt.value}
                className={
                  'cursor-pointer rounded-lg border p-3 text-sm ' +
                  (form.level === opt.value
                    ? 'border-green-700 bg-green-700/5 dark:border-gold dark:bg-gold/10'
                    : 'border-ink/15 dark:border-paper/20')
                }
              >
                <input
                  type="radio"
                  name="level"
                  className="sr-only"
                  checked={form.level === opt.value}
                  onChange={() => setForm({ ...form, level: opt.value })}
                />
                <p className="font-medium text-ink dark:text-paper">{opt.label}</p>
                <p className="mt-0.5 text-xs text-ink/50 dark:text-paper/50">{opt.hint}</p>
              </label>
            ))}
          </div>
        </div>

        {(form.level === 'state' || form.level === 'local') && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="state" className="block text-sm font-medium text-ink dark:text-paper">
                State
              </label>
              <input
                id="state"
                required
                value={form.state}
                onChange={(e) => setForm({ ...form, state: e.target.value })}
                placeholder="e.g. Kogi"
                className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
              />
            </div>
            {form.level === 'local' && (
              <div>
                <label htmlFor="lga" className="block text-sm font-medium text-ink dark:text-paper">
                  Local Government Area
                </label>
                <input
                  id="lga"
                  required
                  value={form.lga}
                  onChange={(e) => setForm({ ...form, lga: e.target.value })}
                  placeholder="e.g. Ankpa"
                  className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
                />
              </div>
            )}
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="startsAt" className="block text-sm font-medium text-ink dark:text-paper">
              Polling opens
            </label>
            <input
              id="startsAt"
              type="datetime-local"
              required
              value={form.startsAt}
              onChange={(e) => setForm({ ...form, startsAt: e.target.value })}
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
          </div>
          <div>
            <label htmlFor="endsAt" className="block text-sm font-medium text-ink dark:text-paper">
              Polling closes
            </label>
            <input
              id="endsAt"
              type="datetime-local"
              required
              value={form.endsAt}
              onChange={(e) => setForm({ ...form, endsAt: e.target.value })}
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="timezone" className="block text-sm font-medium text-ink dark:text-paper">
              Timezone
            </label>
            <select
              id="timezone"
              value={form.timezone}
              onChange={(e) => setForm({ ...form, timezone: e.target.value })}
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            >
              {timezones.map((tz) => (
                <option key={tz}>{tz}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="lockDate" className="block text-sm font-medium text-ink dark:text-paper">
              Roster lock date
            </label>
            <input
              id="lockDate"
              type="date"
              required
              value={form.lockDate}
              onChange={(e) => setForm({ ...form, lockDate: e.target.value })}
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
            <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
              Parties/candidates can no longer be edited after this date.
            </p>
          </div>
        </div>

        <button
          type="submit"
          className="rounded-full bg-green-700 px-6 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Save election
        </button>
      </form>

      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Configured elections
      </h2>
      {elections.length === 0 ? (
        <p className="mt-3 text-sm text-ink/50 dark:text-paper/50">None yet — add one above.</p>
      ) : (
        <div className="mt-4 space-y-3">
          {elections.map((e) => (
            <div
              key={e.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal"
            >
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-ink dark:text-paper">{e.name}</p>
                  <span className="rounded-full bg-ink/10 px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide text-ink/60 dark:bg-paper/10 dark:text-paper/60">
                    {e.level}
                    {e.level === 'state' && e.state ? ` · ${e.state}` : ''}
                    {e.level === 'local' && e.lga ? ` · ${e.lga}, ${e.state}` : ''}
                  </span>
                </div>
                <p className="text-xs text-ink/50 dark:text-paper/50">
                  {e.startsAt || '—'} → {e.endsAt || '—'} · {e.timezone}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span
                  className={
                    e.status === 'locked'
                      ? 'rounded-full bg-ink/10 px-2.5 py-0.5 text-xs font-medium text-ink/60 dark:bg-paper/10 dark:text-paper/60'
                      : 'rounded-full bg-green-700/10 px-2.5 py-0.5 text-xs font-medium text-green-700 dark:bg-gold/10 dark:text-gold'
                  }
                >
                  {e.status === 'locked' ? 'Roster locked' : 'Draft'}
                </span>
                {e.status === 'draft' && (
                  <button
                    onClick={() => lockRoster(e.id)}
                    className="rounded-full border border-ink/20 px-3 py-1 text-xs font-semibold text-ink dark:border-paper/30 dark:text-paper"
                  >
                    Lock roster
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
