import { useState } from 'react'
import EmblemLogo from '../../components/EmblemLogo'
import PartyBadge from '../../components/PartyBadge'

type Party = {
  id: string
  name: string
  acronym: string
  candidateName: string
}

const seedParties: Party[] = [
  { id: 'p1', name: 'All Progressives Congress', acronym: 'APC', candidateName: '' },
  { id: 'p2', name: 'Peoples Democratic Party', acronym: 'PDP', candidateName: '' },
]

export default function PartyOnboarding() {
  const [locked, setLocked] = useState(false)
  const [parties, setParties] = useState<Party[]>(seedParties)
  const [form, setForm] = useState({ name: '', acronym: '', candidateName: '' })

  function addParty(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/elections/:id/parties — multipart upload for logo/photo in
    // the real build; omitted here since this is UI scaffolding.
    setParties((list) => [...list, { id: crypto.randomUUID(), ...form }])
    setForm({ name: '', acronym: '', candidateName: '' })
  }

  function removeParty(id: string) {
    setParties((list) => list.filter((p) => p.id !== id))
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">
          Party &amp; candidate onboarding
        </h1>
      </div>

      {locked ? (
        <div className="rounded-xl border border-ink/15 bg-ink/5 p-4 text-sm text-ink/70 dark:border-paper/15 dark:bg-paper/5 dark:text-paper/70">
          This roster is locked — it can no longer be edited. To make changes, an election admin
          must first re-open it from Election Setup before the voting window begins.
        </div>
      ) : (
        <form
          onSubmit={addParty}
          className="grid gap-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal sm:grid-cols-2"
        >
          <div className="sm:col-span-2">
            <label htmlFor="pname" className="block text-sm font-medium text-ink dark:text-paper">
              Party name
            </label>
            <input
              id="pname"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
          </div>
          <div>
            <label htmlFor="acronym" className="block text-sm font-medium text-ink dark:text-paper">
              Acronym
            </label>
            <input
              id="acronym"
              required
              maxLength={10}
              value={form.acronym}
              onChange={(e) => setForm({ ...form, acronym: e.target.value.toUpperCase() })}
              placeholder="e.g. LP"
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 uppercase text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
          </div>
          <div>
            <label htmlFor="candidateName" className="block text-sm font-medium text-ink dark:text-paper">
              Candidate name
            </label>
            <input
              id="candidateName"
              required
              value={form.candidateName}
              onChange={(e) => setForm({ ...form, candidateName: e.target.value })}
              className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-ink dark:text-paper">
              Party logo &amp; candidate photo
            </label>
            <div className="mt-1 flex gap-3">
              <div className="flex h-16 flex-1 items-center justify-center rounded-lg border border-dashed border-ink/25 text-xs text-ink/40 dark:border-paper/25 dark:text-paper/40">
                Upload logo
              </div>
              <div className="flex h-16 flex-1 items-center justify-center rounded-lg border border-dashed border-ink/25 text-xs text-ink/40 dark:border-paper/25 dark:text-paper/40">
                Upload candidate photo
              </div>
            </div>
          </div>
          <button
            type="submit"
            className="rounded-full bg-green-700 px-6 py-2.5 font-semibold text-white hover:bg-green-900 sm:col-span-2"
          >
            Add to roster
          </button>
        </form>
      )}

      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Current roster ({parties.length})
      </h2>
      <div className="mt-4 space-y-3">
        {parties.map((p) => (
          <div
            key={p.id}
            className="flex items-center justify-between rounded-xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal"
          >
            <div className="flex items-center gap-4">
              <div className="flex h-10 w-10 items-center justify-center">
                <PartyBadge party={p.acronym} />
              </div>
              <div>
                <p className="font-medium text-ink dark:text-paper">{p.name}</p>
                <p className="text-xs text-ink/50 dark:text-paper/50">
                  {p.candidateName || 'No candidate assigned yet'}
                </p>
              </div>
            </div>
            {!locked && (
              <button
                onClick={() => removeParty(p.id)}
                className="text-xs font-semibold text-red-600 hover:underline"
              >
                Remove
              </button>
            )}
          </div>
        ))}
      </div>

      {!locked && parties.length > 0 && (
        <button
          onClick={() => setLocked(true)}
          className="mt-6 rounded-full border border-ink/20 px-5 py-2.5 text-sm font-semibold text-ink dark:border-paper/30 dark:text-paper"
        >
          Lock this roster
        </button>
      )}
    </div>
  )
}
