import { useEffect, useState } from 'react'
import EmblemLogo from '../../components/EmblemLogo'
import Skeleton from '../../components/Skeleton'

type VoterRow = {
  id: string
  name: string
  pvc: string
  submittedAt: string
  status: 'pending' | 'approved' | 'rejected'
}

const seed: VoterRow[] = [
  { id: 'v1', name: 'Chidinma O.', pvc: '90F5A2B1C3D4', submittedAt: '2h ago', status: 'pending' },
  { id: 'v2', name: 'Bala M.', pvc: '77K1A9C2E5F0', submittedAt: '5h ago', status: 'pending' },
  { id: 'v3', name: 'Ngozi E.', pvc: '12B8D4A7F1C9', submittedAt: '1d ago', status: 'approved' },
]

export default function VoterRoll() {
  const [loading, setLoading] = useState(true)
  const [voters, setVoters] = useState<VoterRow[]>([])

  useEffect(() => {
    // GET /api/voters?status=pending in the real build
    const t = setTimeout(() => {
      setVoters(seed)
      setLoading(false)
    }, 500)
    return () => clearTimeout(t)
  }, [])

  function decide(id: string, status: 'approved' | 'rejected') {
    // PATCH /api/voters/:id/verification — also triggers the duplicate-
    // account check (NIN hash + face-template hash) before approval.
    setVoters((list) => list.map((v) => (v.id === id ? { ...v, status } : v)))
  }

  const pending = voters.filter((v) => v.status === 'pending')
  const decided = voters.filter((v) => v.status !== 'pending')

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">
          Voter roll &amp; verification queue
        </h1>
      </div>

      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
      ) : (
        <>
      <h2 className="font-serif text-lg font-semibold text-ink dark:text-paper">
        Pending review ({pending.length})
      </h2>
      <div className="mt-3 space-y-3">
        {pending.length === 0 && (
          <p className="text-sm text-ink/50 dark:text-paper/50">Nothing waiting on you right now.</p>
        )}
        {pending.map((v) => (
          <div
            key={v.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal"
          >
            <div>
              <p className="font-medium text-ink dark:text-paper">{v.name}</p>
              <p className="text-xs text-ink/50 dark:text-paper/50">
                PVC {v.pvc} · NIN, voter card &amp; face check submitted {v.submittedAt}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => decide(v.id, 'rejected')}
                className="rounded-full border border-red-600/40 px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-600/10"
              >
                Reject
              </button>
              <button
                onClick={() => decide(v.id, 'approved')}
                className="rounded-full bg-green-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-green-900"
              >
                Approve
              </button>
            </div>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Decided
      </h2>
      <div className="mt-3 space-y-2">
        {decided.map((v) => (
          <div
            key={v.id}
            className="flex items-center justify-between rounded-xl border border-ink/10 bg-white p-3 text-sm dark:border-paper/10 dark:bg-charcoal"
          >
            <span className="text-ink dark:text-paper">{v.name}</span>
            <span
              className={
                v.status === 'approved'
                  ? 'rounded-full bg-green-700/10 px-2.5 py-0.5 text-xs font-medium text-green-700 dark:bg-gold/10 dark:text-gold'
                  : 'rounded-full bg-red-600/10 px-2.5 py-0.5 text-xs font-medium text-red-600'
              }
            >
              {v.status === 'approved' ? 'Approved' : 'Rejected'}
            </span>
          </div>
        ))}
      </div>
        </>
      )}
    </div>
  )
}
