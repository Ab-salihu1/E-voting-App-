import { useEffect, useState } from 'react'
import EmblemLogo from '../../components/EmblemLogo'
import Skeleton from '../../components/Skeleton'

type Incident = {
  id: string
  title: string
  severity: 'low' | 'medium' | 'high'
  status: 'open' | 'resolved'
  reportedAt: string
}

const seed: Incident[] = [
  { id: 'i1', title: 'Slow load times reported in Kano North', severity: 'low', status: 'open', reportedAt: '3h ago' },
  { id: 'i2', title: 'Duplicate-account flag under review', severity: 'medium', status: 'open', reportedAt: '1d ago' },
]

const severityStyle: Record<Incident['severity'], string> = {
  low: 'bg-ink/10 text-ink/60 dark:bg-paper/10 dark:text-paper/60',
  medium: 'bg-gold/20 text-gold-600 dark:bg-gold/20 dark:text-gold',
  high: 'bg-red-600/10 text-red-600',
}

export default function Incidents() {
  const [loading, setLoading] = useState(true)
  const [incidents, setIncidents] = useState<Incident[]>([])
  const [title, setTitle] = useState('')

  useEffect(() => {
    // GET /api/incidents in the real build
    const t = setTimeout(() => {
      setIncidents(seed)
      setLoading(false)
    }, 450)
    return () => clearTimeout(t)
  }, [])

  function addIncident(e: React.FormEvent) {
    e.preventDefault()
    if (!title.trim()) return
    setIncidents((list) => [
      { id: crypto.randomUUID(), title, severity: 'low', status: 'open', reportedAt: 'just now' },
      ...list,
    ])
    setTitle('')
  }

  function resolve(id: string) {
    setIncidents((list) => list.map((i) => (i.id === id ? { ...i, status: 'resolved' } : i)))
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">
          Incident management
        </h1>
      </div>

      <form
        onSubmit={addIncident}
        className="flex gap-3 rounded-2xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal"
      >
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Log a new incident…"
          className="flex-1 rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
        />
        <button
          type="submit"
          className="rounded-full bg-green-700 px-5 py-2 text-sm font-semibold text-white hover:bg-green-900"
        >
          Log
        </button>
      </form>

      <div className="mt-6 space-y-3">
        {loading && (
          <>
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </>
        )}
        {!loading && incidents.map((i) => (
          <div
            key={i.id}
            className="rounded-xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-medium text-ink dark:text-paper">{i.title}</p>
                <p className="text-xs text-ink/50 dark:text-paper/50">Reported {i.reportedAt}</p>
              </div>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${severityStyle[i.severity]}`}>
                {i.severity}
              </span>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <span
                className={
                  i.status === 'open'
                    ? 'text-xs font-medium text-gold-600 dark:text-gold'
                    : 'text-xs font-medium text-green-700 dark:text-green-500'
                }
              >
                {i.status === 'open' ? 'Open' : 'Resolved'}
              </span>
              {i.status === 'open' && (
                <button
                  onClick={() => resolve(i.id)}
                  className="rounded-full border border-ink/20 px-3 py-1 text-xs font-semibold text-ink dark:border-paper/30 dark:text-paper"
                >
                  Mark resolved
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
