import { useState } from 'react'
import EmblemLogo from '../../components/EmblemLogo'

type AdminAccount = {
  id: string
  name: string
  role: string
  status: 'active' | 'revoked'
}

const initialAdmins: AdminAccount[] = [
  { id: 'a1', role: 'Chairman', name: 'Prof. Joash Ojo Amupitan, SAN', status: 'active' },
  { id: 'a2', role: 'National Commissioner — North Central', name: '— unassigned —', status: 'active' },
  { id: 'a3', role: 'Election Officer — Lagos State', name: 'Demo Officer', status: 'active' },
]

export default function ManageAdmins() {
  const [admins, setAdmins] = useState(initialAdmins)

  function revoke(id: string) {
    setAdmins((list) =>
      list.map((a) => (a.id === id ? { ...a, status: 'revoked' } : a)),
    )
    // In the real backend: DELETE /api/admin/:id/revoke
    // — immediately invalidates that admin's session/tokens and disables login,
    // it does NOT just hide them from this list.
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <div>
          <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
            Manage commission accounts
          </p>
          <p className="text-xs text-ink/50 dark:text-paper/50">Super-admin only</p>
        </div>
      </div>

      <div className="mb-6 rounded-xl border border-gold/40 bg-gold/10 p-4 text-sm text-ink/80 dark:text-paper/80">
        When a role changes hands — a new Chairman is sworn in, a Commissioner's term ends, a
        staff member is reassigned — revoke the outgoing holder's account here <em>first</em>,
        then send a fresh invite for the incoming official. A role is never handed over by editing
        the old account's name/password; that would carry over the old holder's session and
        credentials to the new person, which is exactly what we don't want.
      </div>

      <div className="overflow-hidden rounded-2xl border border-ink/10 dark:border-paper/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-ink/60 dark:bg-paper/5 dark:text-paper/60">
            <tr>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Assigned to</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/10 dark:divide-paper/10">
            {admins.map((admin) => (
              <tr key={admin.id} className="bg-white dark:bg-charcoal">
                <td className="px-4 py-3 text-ink dark:text-paper">{admin.role}</td>
                <td className="px-4 py-3 text-ink/80 dark:text-paper/80">{admin.name}</td>
                <td className="px-4 py-3">
                  <span
                    className={
                      admin.status === 'active'
                        ? 'rounded-full bg-green-700/10 px-2.5 py-0.5 text-xs font-medium text-green-700 dark:bg-gold/10 dark:text-gold'
                        : 'rounded-full bg-ink/10 px-2.5 py-0.5 text-xs font-medium text-ink/50 dark:bg-paper/10 dark:text-paper/40'
                    }
                  >
                    {admin.status === 'active' ? 'Active' : 'Revoked'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  {admin.status === 'active' ? (
                    <button
                      onClick={() => revoke(admin.id)}
                      className="rounded-full border border-red-600/40 px-3 py-1 text-xs font-semibold text-red-600 hover:bg-red-600/10"
                    >
                      Revoke access
                    </button>
                  ) : (
                    <button className="rounded-full border border-green-700/40 px-3 py-1 text-xs font-semibold text-green-700 hover:bg-green-700/10 dark:border-gold/40 dark:text-gold">
                      Invite replacement
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
