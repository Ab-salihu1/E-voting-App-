import { Link } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'

const cards = [
  {
    to: '/admin/elections',
    title: 'Election setup & scheduling',
    body: 'Create an election, set the voting window (start/end date-time, timezone), and lock date.',
  },
  {
    to: '/admin/parties',
    title: 'Party & candidate onboarding',
    body: 'Upload parties (PDP, APC, LP, NNPP…) with logos, and assign candidates before the roster locks.',
  },
  {
    to: '/admin/voters',
    title: 'Voter roll & verification',
    body: 'Review and approve or reject pending NIN/voter-card/face verifications.',
  },
  {
    to: '/admin/incidents',
    title: 'Incident management',
    body: 'Log, track, and resolve reported incidents — including ones submitted publicly.',
  },
  {
    to: '/admin/notifications',
    title: 'Notification broadcast',
    body: 'Send updates to all verified voters, staff, or unverified accounts.',
  },
  {
    to: '/admin/audit-log',
    title: 'Audit log',
    body: 'Read-only, tamper-evident record of every admin and system action.',
  },
  {
    to: '/admin/manage',
    title: 'Manage accounts & access',
    body: 'Revoke an outgoing official\u2019s access and invite their replacement.',
  },
]

const stats = [
  { label: 'Registered voters', value: '—' },
  { label: 'Verified voters', value: '—' },
  { label: 'Elections configured', value: '0' },
  { label: 'Open incidents', value: '0' },
]

export default function AdminDashboard() {
  return (
    <div className="mx-auto max-w-5xl px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <div>
          <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">
            Commission admin dashboard
          </h1>
          <p className="text-sm text-ink/60 dark:text-paper/60">System overview</p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-ink/10 bg-white p-4 dark:border-paper/10 dark:bg-charcoal">
            <p className="font-serif text-2xl font-semibold text-ink dark:text-paper">{s.value}</p>
            <p className="text-xs text-ink/50 dark:text-paper/50">{s.label}</p>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-serif text-lg font-semibold text-ink dark:text-paper">
        Set up an election
      </h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <Link
            key={c.to}
            to={c.to}
            className="rounded-2xl border border-ink/10 bg-white p-5 transition hover:border-green-700/40 dark:border-paper/10 dark:bg-charcoal dark:hover:border-gold/40"
          >
            <p className="font-semibold text-ink dark:text-paper">{c.title}</p>
            <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">{c.body}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
