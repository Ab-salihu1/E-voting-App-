import { useEffect, useState } from 'react'
import EmblemLogo from '../../components/EmblemLogo'
import Skeleton from '../../components/Skeleton'

const seedEntries = [
  { id: 'l1', time: '2027-02-13 08:00:02', actor: 'system', action: 'Election "Presidential" opened for voting' },
  { id: 'l2', time: '2027-02-12 17:45:11', actor: 'admin:a1', action: 'Locked party/candidate roster' },
  { id: 'l3', time: '2027-02-10 09:12:40', actor: 'admin:a3', action: 'Approved voter verification (PVC 90F5…D4)' },
  { id: 'l4', time: '2027-02-09 14:03:27', actor: 'super-admin', action: 'Revoked admin access (role: Chairman, outgoing)' },
]

export default function AuditLog() {
  const [loading, setLoading] = useState(true)
  const [entries, setEntries] = useState<typeof seedEntries>([])

  useEffect(() => {
    // GET /api/audit-log in the real build, paginated
    const t = setTimeout(() => {
      setEntries(seedEntries)
      setLoading(false)
    }, 500)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <div className="mb-6 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <h1 className="font-serif text-2xl font-semibold text-ink dark:text-paper">Audit log</h1>
      </div>

      <p className="mb-6 text-sm text-ink/60 dark:text-paper/60">
        Append-only and hash-chained — each entry below would carry a hash of the entry before it,
        so removing or editing a past entry breaks every hash after it. Read-only, including for
        admins.
      </p>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : (
        <>
          <div className="overflow-hidden rounded-2xl border border-ink/10 dark:border-paper/10">
            <table className="w-full text-left text-sm">
              <thead className="bg-ink/5 text-ink/60 dark:bg-paper/5 dark:text-paper/60">
                <tr>
                  <th className="px-4 py-3 font-medium">Time</th>
                  <th className="px-4 py-3 font-medium">Actor</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/10 dark:divide-paper/10">
                {entries.map((e) => (
                  <tr key={e.id} className="bg-white dark:bg-charcoal">
                    <td className="px-4 py-3 font-mono text-xs text-ink/60 dark:text-paper/60">{e.time}</td>
                    <td className="px-4 py-3 text-ink/80 dark:text-paper/80">{e.actor}</td>
                    <td className="px-4 py-3 text-ink dark:text-paper">{e.action}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <button className="mt-6 rounded-full border border-ink/20 px-5 py-2.5 text-sm font-semibold text-ink dark:border-paper/30 dark:text-paper">
            Export as CSV
          </button>
        </>
      )}
    </div>
  )
}
