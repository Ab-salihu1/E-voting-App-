import EmblemLogo from '../../components/EmblemLogo'

export default function AdminSignup() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <div>
          <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
            Activate your commission account
          </p>
          <p className="text-xs text-ink/50 dark:text-paper/50">
            Chairman, Commissioner &amp; staff accounts are invite-only
          </p>
        </div>
      </div>

      <div className="mb-6 rounded-xl border border-gold/40 bg-gold/10 p-4 text-sm text-ink/80 dark:text-paper/80">
        By design, nobody can open this page and register themselves as an admin — including as
        Chairman. A sitting super-admin issues a one-time invite code to a verified official's
        official email first. This screen only <em>activates</em> that invite; it never creates a
        brand-new privileged account on its own.
      </div>

      <form className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div>
          <label htmlFor="inviteCode" className="block text-sm font-medium text-ink dark:text-paper">
            Invite code
          </label>
          <input
            id="inviteCode"
            type="text"
            placeholder="Sent to your official @inec.gov.ng email"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-ink dark:text-paper">
            Full name
          </label>
          <input
            id="fullName"
            type="text"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <div>
          <label htmlFor="newPassword" className="block text-sm font-medium text-ink dark:text-paper">
            Create password
          </label>
          <input
            id="newPassword"
            type="password"
            autoComplete="new-password"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Activate account &amp; set up MFA
        </button>
      </form>
    </div>
  )
}
