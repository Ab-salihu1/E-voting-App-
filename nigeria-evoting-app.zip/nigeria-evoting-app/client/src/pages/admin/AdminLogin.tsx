import { Link, useNavigate } from 'react-router-dom'
import EmblemLogo from '../../components/EmblemLogo'

export default function AdminLogin() {
  const navigate = useNavigate()

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    // POST /api/admin/login — verify credentials + mandatory MFA code
    navigate('/admin/dashboard')
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-8 flex items-center gap-3">
        <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
        <div>
          <p className="font-serif text-lg font-semibold text-ink dark:text-paper">
            Commission Admin Portal
          </p>
          <p className="text-xs text-ink/50 dark:text-paper/50">
            For INEC Chairman, Commissioners &amp; authorised staff only
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-ink/10 bg-white p-6 dark:border-paper/10 dark:bg-charcoal">
        <div>
          <label htmlFor="staffId" className="block text-sm font-medium text-ink dark:text-paper">
            Staff ID or official email
          </label>
          <input
            id="staffId"
            type="text"
            autoComplete="username"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <div>
          <label htmlFor="password" className="block text-sm font-medium text-ink dark:text-paper">
            Password
          </label>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
        </div>
        <div>
          <label htmlFor="mfaCode" className="block text-sm font-medium text-ink dark:text-paper">
            Authenticator code
          </label>
          <input
            id="mfaCode"
            type="text"
            inputMode="numeric"
            placeholder="6-digit code"
            className="mt-1 w-full rounded-lg border border-ink/15 bg-transparent px-3 py-2 text-ink outline-none focus:border-green-700 dark:border-paper/20 dark:text-paper"
          />
          <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">
            MFA is mandatory for every admin account — no exceptions, including the Chairman.
          </p>
        </div>
        <button
          type="submit"
          className="w-full rounded-full bg-green-700 py-2.5 font-semibold text-white hover:bg-green-900"
        >
          Sign in
        </button>
      </form>

      <p className="mt-5 text-center text-sm text-ink/60 dark:text-paper/60">
        New commission staff need an invitation.{' '}
        <Link to="/admin/signup" className="font-medium text-green-700 dark:text-gold">
          Activate an invite
        </Link>
      </p>
      <p className="mt-2 text-center text-sm text-ink/60 dark:text-paper/60">
        Super-admin?{' '}
        <Link to="/admin/manage" className="font-medium text-green-700 dark:text-gold">
          Manage accounts &amp; access
        </Link>
      </p>
    </div>
  )
}
