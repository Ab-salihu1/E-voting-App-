type Props = {
  party: string
  size?: 'sm' | 'md' | 'lg'
}

// Original app palette for visual distinction only — deliberately NOT the
// real parties' official brand colors/logos/symbols, just enough contrast
// to tell contestants apart at a glance in this demo.
const palette: Record<string, string> = {
  APC: '#1D4ED8',
  PDP: '#047857',
  LP: '#B45309',
  NNPP: '#7C2D82',
}

const sizeClasses = {
  sm: 'h-6 w-6 text-[10px]',
  md: 'h-10 w-10 text-xs',
  lg: 'h-12 w-12 text-sm',
}

export default function PartyBadge({ party, size = 'md' }: Props) {
  const color = palette[party] ?? '#4B5563'
  return (
    <span
      className={`flex shrink-0 items-center justify-center rounded-full font-semibold text-white ${sizeClasses[size]}`}
      style={{ backgroundColor: color }}
    >
      {party}
    </span>
  )
}
