import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="border-t border-ink/10 dark:border-paper/10">
      <div className="flag-band">
        <span /><span /><span />
      </div>
      <div className="mx-auto max-w-6xl px-6 py-10 text-sm text-ink/60 dark:text-paper/60">
        <p className="max-w-2xl">
          NaijaVote is a conceptual design project exploring secure digital voting for Nigeria.
          It is not affiliated with, endorsed by, or authorised by INEC or the Government of
          Nigeria.
        </p>
        <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2">
          <a href="#" className="hover:text-ink dark:hover:text-paper">Help centre</a>
          <a href="#" className="hover:text-ink dark:hover:text-paper">Accessibility</a>
          <a href="#" className="hover:text-ink dark:hover:text-paper">Privacy</a>
          <Link to="/transparency" className="hover:text-ink dark:hover:text-paper">Report an incident</Link>
          <Link to="/leadership" className="hover:text-ink dark:hover:text-paper">Commission leadership</Link>
          <Link to="/admin/login" className="hover:text-ink dark:hover:text-paper">Admin portal</Link>
        </div>
      </div>
    </footer>
  )
}
