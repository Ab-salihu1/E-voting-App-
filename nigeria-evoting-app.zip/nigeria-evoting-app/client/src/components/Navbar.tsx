import { useState } from 'react'
import { Link } from 'react-router-dom'
import EmblemLogo from './EmblemLogo'

export default function Navbar() {
  const [dark, setDark] = useState(false)

  function toggleDark() {
    setDark((d) => {
      document.documentElement.classList.toggle('dark', !d)
      return !d
    })
  }

  return (
    <header>
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <a href="#top" className="flex items-center gap-3 text-ink dark:text-paper">
          <EmblemLogo className="h-9 w-9 text-green-700 dark:text-gold" />
          <span className="font-serif text-lg font-semibold tracking-tight">NaijaVote</span>
        </a>
        <div className="flex items-center gap-6">
          <a href="#how-it-works" className="hidden text-sm font-medium text-ink/80 hover:text-ink dark:text-paper/80 dark:hover:text-paper sm:inline">
            How it works
          </a>
          <a href="#security" className="hidden text-sm font-medium text-ink/80 hover:text-ink dark:text-paper/80 dark:hover:text-paper sm:inline">
            Security
          </a>
          <Link to="/leadership" className="hidden text-sm font-medium text-ink/80 hover:text-ink dark:text-paper/80 dark:hover:text-paper sm:inline">
            Leadership
          </Link>
          <Link to="/transparency" className="hidden text-sm font-medium text-ink/80 hover:text-ink dark:text-paper/80 dark:hover:text-paper sm:inline">
            Transparency
          </Link>
          <button
            onClick={toggleDark}
            aria-label="Toggle dark mode"
            className="rounded-full border border-ink/15 px-3 py-1.5 text-sm font-medium text-ink/80 hover:border-ink/30 dark:border-paper/20 dark:text-paper/80"
          >
            {dark ? 'Light' : 'Dark'}
          </button>
          <Link
            to="/signup"
            className="rounded-full bg-green-700 px-4 py-2 text-sm font-semibold text-white hover:bg-green-900"
          >
            Register to vote
          </Link>
        </div>
      </nav>
      {/* flag-style ribbon band */}
      <div className="flag-band">
        <span /><span /><span />
      </div>
    </header>
  )
}
