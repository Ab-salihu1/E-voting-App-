# NaijaVote — Nigeria 2027 E-Voting Concept

⚠️ Conceptual project only. Not affiliated with, endorsed by, or authorised by INEC or the
Government of Nigeria.

## Structure

```
nigeria-evoting-app/
  client/   React + Vite + Tailwind frontend — every screen below is built and wired up
  server/   Express backend — route stubs with implementation notes, no database yet
```

## Run the frontend

```
cd client
npm install
npm run dev
```

Opens at http://localhost:5173.

## Run the backend

```
cd server
npm install
npm run dev
```

Health check at http://localhost:4000/health. Every route currently returns `501 Not
implemented` with a comment describing exactly what real logic belongs there.

## Screen-by-screen structure (all built)

**Public**
- `/` — Landing: hero, live public tally (0% until polling opens), how-it-works, security, languages
- `/leadership` — Commission leadership (real current INEC Chairman + placeholder commissioner seats)
- `/transparency` — Observer/transparency portal: turnout stats, live tally by contest, audit-trail summary, public incident reporting

**Citizen onboarding** (`/signup` → `/verify/complete`)
1. Sign up (email + password, strength meter)
2. Verify NIN
3. Verify OTP
4. Set up MFA (optional)
5. Verify voter card (PVC)
6. Facial capture + liveness check (real camera access)
7. Verification submitted / success

**Citizen dashboard & voting** (`/dashboard`, `/vote/*`)
- Dashboard: verification status, vote status, live countdown, notifications
- Vote-login gate (PVC + NIN)
- Fresh liveness re-check (mandatory every session)
- Eligibility declaration (radio button, required before ballot)
- Multi-contest ballot (President → Governor → State Assembly → LG Chairman → Councillor, whichever apply)
- Review all selections
- Confirm & submit
- Receipt (deterministic, non-random reference code)

**Admin/commission portal** (`/admin/*`)
- Login (staff ID/email + password + mandatory MFA)
- Invite-activation (no open self-signup, by design — a super-admin issues invites)
- Dashboard hub with live overview stats
- Election setup & scheduling (Federal/State/Local scope, voting window, roster lock)
- Party & candidate onboarding (with roster lock)
- Voter roll & verification queue (approve/reject)
- Incident management (log + resolve)
- Notification broadcast centre
- Audit log (read-only, tamper-evident)
- Manage accounts & access (revoke outgoing officials, invite replacements)

## Essential vs advanced features

**Essential (all built on the frontend)**
- Email + password sign-up, NIN verification, OTP, optional MFA
- Voter card verification, facial capture, liveness check
- Citizen eligibility declaration
- Multi-level election support (Federal / State / Local Government)
- One-vote-per-token enforcement design, anonymized ballot storage, deterministic receipts
- Voter dashboard, admin portal, observer/transparency portal
- Green/white/gold theme with the Nigerian coat of arms, light/dark mode
- Multi-language chips (English, Hausa, Yoruba, Igbo, Pidgin) — display only, not yet functional i18n

**Advanced (not built — noted for later)**
- Real NIN/NIMC integration, real liveness-detection ML service
- Functional i18n (actual translated strings, not just chips)
- Blockchain-anchored audit log, AI fraud/anomaly detection
- Offline/USSD fallback, independent third-party audit API
- Zero-knowledge tally verification

## Security notes baked into the code

- Vote reference codes and voting tokens are generated **deterministically** (HMAC-style hash of
  token + timestamp) — never from a random number generator
- Vote-time login (PVC + NIN) is paired with a **mandatory fresh liveness check** every session,
  since PVC + NIN alone aren't secret enough on their own
- Admin/Chairman accounts are **invite-only** — there is no self-registration path for privileged
  roles
- Revoking an admin's access is a distinct action from editing their account, so sessions/tokens
  can't carry over to a new office-holder
- Identity data and ballot content are designed to live in separate stores, linked only by a
  single-use token — see comments in `server/src/routes/ballots.js`

## Recommended tech stack (for a real build)

| Layer | Recommendation |
|---|---|
| Frontend | React + Vite + TypeScript + Tailwind (what this scaffold uses) |
| Backend | Node.js (Express, as scaffolded) or NestJS for a larger team |
| Database | PostgreSQL (voter registry + ballot store kept as separate schemas/services) |
| Identity/Biometric | Dedicated microservice wrapping a NIN/NIMC-style API + a real liveness SDK |
| Audit log | Hash-chained append-only table, or a permissioned ledger (e.g. Hyperledger Fabric) for the advanced version |
| Infra | Kubernetes, multi-AZ, WAF + DDoS protection (e.g. Cloudflare), encrypted backups |
| CI/CD | GitHub Actions with automated tests, load testing (k6), and pen-testing before releases |

## What's real vs. simulated right now

- **Real**: routing, all UI/UX, form state, the camera-based liveness capture, the deterministic
  hash used for receipts, dark mode
- **Simulated**: every backend call (routes exist but return `501`), NIN/voter-card verification
  against a real registry, actual liveness ML matching, persistence of any kind (nothing survives
  a page refresh except what's kept in `sessionStorage` during the vote flow)

## Next step

The full feature list from the original spec is now built as UI. The real remaining work is a
database schema (voter registry, ballot store, elections, parties, audit log) and wiring the
~20 backend route stubs to it, one by one.
